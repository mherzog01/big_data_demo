#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "Mike0001"
db_name = "scale_aws" 
db_port = 3306
db_instance = "demo-db-1.cq2s02rjdpvt.us-east-1.rds.amazonaws.com"
#db_instance = "mysqlforlambdademo.cq2s02rjdpvt.us-east-1.rds.amazonaws.com"