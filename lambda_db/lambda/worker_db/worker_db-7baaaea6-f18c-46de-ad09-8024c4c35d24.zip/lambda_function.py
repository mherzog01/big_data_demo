import sys
import logging
import rds_config
import pymysql
import json

#rds settings
rds_host  = rds_config.db_instance
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name
port = rds_config.db_port

logger = logging.getLogger()
logger.setLevel(logging.INFO)

logger.info(f"INFO: Trying to connect to MySQL instance {rds_host} {db_name}.")
#logger.info(f"INFO: Trying to connect to MySQL instance " + rds_host + " " + db_name + ".")
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error(f"ERROR: Unexpected error: Could not connect to MySQL instance {rds_host} {db_name}.")
    #logger.error(f"ERROR: Unexpected error: Could not connect to MySQL instance " + rds_host + " " + db_name + ".")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """

    item_count = 0

    with conn.cursor() as cur:
        worker_nums = []
        for record in event['Records']:
            payload = record["body"]
            payload_json = json.loads(payload)
            worker_num = payload_json.get('worker_num')
            worker_nums.append(worker_num)
            item_count += 1
            cur.execute(f'insert into demo_scale values(current_timestamp(), {worker_num})')
        conn.commit()
    return f"Added {item_count} items to the RDS MySQL table" 