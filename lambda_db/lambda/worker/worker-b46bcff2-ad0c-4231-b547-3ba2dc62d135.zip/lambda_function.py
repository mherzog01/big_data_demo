import json
import time

def lambda_handler(event, context):
    worker_nums = []
    # If called directly from a client, worker_num will not be None
    worker_num = event.get('worker_num')
    if worker_num:
        worker_nums.append(worker_num)
    else:
        # https://docs.aws.amazon.com/lambda/latest/dg/with-sqs-create-package.html#with-sqs-example-deployment-pkg-python
        for record in event['Records']:
            payload = record["body"]
            payload_json = json.loads(payload)
            worker_num = payload_json.get('worker_num')
            worker_nums.append(worker_num)

    for worker_num in worker_nums:
        time.sleep(0.5)
    return {
        'statusCode': 200,
        'body': json.dumps(f'worker(s) {worker_nums} completed')
    }
