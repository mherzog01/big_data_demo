import json
import boto3
from typing import List
#from aws_lambda_powertools.event_handler.api_gateway import ApiGatewayEventHandler

# TODO Validate user input

# schema = {
#     "type": "string",
#     "properties": {
#         "filter_chars": {
#             "type": "object",
#             "properties": {
#                 "my_param": {"type": "string"}
#             },
#             "required": ["my_param"]
#         }
#     }
# }

# handler = ApiGatewayEventHandler(schema=schema)

# Source
BUCKET = 'sorel-20m'
PREFIX = '09-DEC-2020/binaries'
BUCKET_PATH = f's3://{BUCKET}'
SRC_PATH = f'{BUCKET_PATH}/{PREFIX}'

# Target
TARG_BUCKET = 'sorel-20m-demo'
TARG_BUCKET_PATH = f's3://{TARG_BUCKET}'
TARG_PREFIX = 'input'
TARG_PATH = f'{TARG_BUCKET_PATH}/{TARG_PREFIX}'

def lambda_handler(event, context):

    filter_chars = event['filter_chars']

    s3 = boto3.resource('s3')
    
    def get_objects(filter_chars: str, bucket: str, prefix: str) -> List[str]:
        bucket = s3.Bucket(bucket)
        prefix = f'{prefix}/{filter_chars}'
        objects = bucket.objects.filter(Prefix=prefix)
        return objects
    
    # Get keys
    objects = get_objects(filter_chars, BUCKET, PREFIX)
    object_list = [o for o in objects]
    
    # Write to S3
    content = ""
    for o in objects:
        content += o.key + '\n'
    s3.Object(TARG_BUCKET, f'{TARG_PREFIX}/keys_{filter_chars}.txt').put(Body=content)

    return {
        'statusCode': 200,
        'body': json.dumps(f'{len(object_list)} objects written to S3')
    }
